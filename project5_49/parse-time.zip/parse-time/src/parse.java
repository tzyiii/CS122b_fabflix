import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class parse {
	

	public static void main(String args[]) {
		
		
		
		int amount=0;
		String path = "slave_log.txt";
		FileInputStream in = null;
		InputStreamReader isr = null;
		BufferedReader br = null;

		try {
			in = new FileInputStream(path);

			isr = new InputStreamReader(in);
			br = new BufferedReader(isr);
			String b;
			
			while ((b = br.readLine()) != null) {
				amount++;
			}
			int sum = amount;
			
			in = new FileInputStream(path);
			isr = new InputStreamReader(in);
			br = new BufferedReader(isr);
			int weight_sum = 0;
			long TS[] = new long[amount];
			long TJ[]= new long[amount];
			amount = 0;
			while ((b = br.readLine()) != null) {
				
					String[] sp = b.split(" ");
					TS[amount] = Long.parseLong(sp[0]);
					TJ[amount] = Long.parseLong(sp[1]);
					amount++;
				}
				Long S=0l, J=0l; 
				for(int i = 0;i<TS.length;i++){
					S=S+TS[i];
					J=J+TJ[i];
				}
				double s = (double)S/sum*10E-9;
				double j = (double)J/sum*10E-9;
			System.out.println(s+"s"+" "+j+"s");
			
			

			br.close();
			isr.close();
			in.close();

		} catch (IOException e1) {
			System.out.println("error");
			System.exit(-1);
		}
	}
}
